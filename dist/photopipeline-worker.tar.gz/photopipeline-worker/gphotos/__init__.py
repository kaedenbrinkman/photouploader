"""Google Photos upload helpers."""
